plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ua.pixel8.ramoptimizer"
    compileSdk = 35
    defaultConfig {
        applicationId = "ua.pixel8.ramoptimizer"
        minSdk = 29
        targetSdk = 35
        versionCode = 5
        versionName = "2.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
