package ua.pixel8.ramoptimizer

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.*
import java.io.File
import java.util.Locale
import kotlin.math.max

class MonitoringService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("gaming_session", Context.MODE_PRIVATE) }
    private val loop = object : Runnable { override fun run() { if (prefs.getBoolean("active", false)) { sample(); handler.postDelayed(this, 2000L) } } }

    override fun onBind(intent: Intent?) = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when(intent?.action) {
            ACTION_STOP -> { stopSession(); return START_NOT_STICKY }
            ACTION_START, null -> startSession()
        }
        return START_STICKY
    }

    private fun startSession() {
        createChannel()
        val now = SystemClock.elapsedRealtime()
        if (!prefs.getBoolean("active", false)) prefs.edit().putBoolean("active", true).putLong("start_elapsed", now)
            .putLong("start_wall", System.currentTimeMillis()).putLong("last_duration", 0L).putFloat("peak_ram", 0f).putInt("peak_temp", -1).putInt("peak_thermal", 0).apply()
        startForeground(NOTIFICATION_ID, notification())
        handler.removeCallbacks(loop); sample(); handler.postDelayed(loop, 2000L)
    }

    private fun sample() {
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
            val pressure = if(mi.totalMem>0) ((mi.totalMem-mi.availMem).toFloat()/mi.totalMem*100f).coerceIn(0f,100f) else 0f
            val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = battery?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            val thermal = if(Build.VERSION.SDK_INT>=29) power.currentThermalStatus else 0
            prefs.edit().putFloat("peak_ram", max(prefs.getFloat("peak_ram",0f), pressure))
                .putInt("peak_temp", if(temp>=0) max(prefs.getInt("peak_temp",-1),temp) else prefs.getInt("peak_temp",-1))
                .putInt("peak_thermal", max(prefs.getInt("peak_thermal",0),thermal))
                .putLong("last_sample", System.currentTimeMillis()).apply()
            val elapsed = (SystemClock.elapsedRealtime()-prefs.getLong("start_elapsed",SystemClock.elapsedRealtime())).coerceAtLeast(0L)
            prefs.edit().putLong("last_duration",elapsed).apply()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, notification())
        } catch (_: Exception) { }
    }

    private fun stopSession() {
        handler.removeCallbacks(loop)
        val elapsed = (SystemClock.elapsedRealtime()-prefs.getLong("start_elapsed",SystemClock.elapsedRealtime())).coerceAtLeast(0L)
        val date = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(java.util.Date(prefs.getLong("start_wall", System.currentTimeMillis())))
        val record = "$date  |  ${(elapsed/60000)} min  |  peak RAM ${String.format(Locale.US,"%.0f%%",prefs.getFloat("peak_ram",0f))}  |  peak battery ${if(prefs.getInt("peak_temp",-1)>=0) String.format(Locale.US,"%.1f°C",prefs.getInt("peak_temp",-1)/10f) else "n/a"}  |  thermal ${prefs.getInt("peak_thermal",0)}"
        val oldHistory = prefs.getString("history", "").orEmpty()
        val newHistory = (listOf(record) + oldHistory.lines().filter { it.isNotBlank() }).take(20).joinToString("\n")
        prefs.edit().putBoolean("active",false).putLong("last_duration",elapsed).putString("history",newHistory).apply()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID,"Gaming session monitor",NotificationManager.IMPORTANCE_LOW).apply { description="Persistent status while background monitoring is active" })
        }
    }

    private fun notification(): Notification {
        val stopIntent=Intent(this,MonitoringService::class.java).setAction(ACTION_STOP)
        val pending=PendingIntent.getService(this,2,stopIntent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open=PendingIntent.getActivity(this,1,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val elapsed=(SystemClock.elapsedRealtime()-prefs.getLong("start_elapsed",SystemClock.elapsedRealtime())).coerceAtLeast(0L)/1000
        val title=String.format(Locale.US,"Gaming monitor · %02d:%02d",elapsed/60,elapsed%60)
        val builder=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_menu_info_details).setContentTitle(title)
            .setContentText("RAM / battery temperature / thermal status sampling active")
            .setContentIntent(open).setOngoing(true).addAction(Notification.Action.Builder(null,"STOP SESSION",pending).build()).build()
    }

    override fun onDestroy() { handler.removeCallbacks(loop); super.onDestroy() }
    companion object {
        const val ACTION_START="ua.pixel8.ramoptimizer.START_MONITOR"
        const val ACTION_STOP="ua.pixel8.ramoptimizer.STOP_MONITOR"
        const val CHANNEL_ID="gaming_monitor_channel"
        const val NOTIFICATION_ID=2606
    }
}
