package ua.pixel8.ramoptimizer

import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import android.provider.Settings
import android.content.IntentFilter
import android.content.Context
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.BufferedReader
import java.io.FileReader
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var ramValue: TextView
    private lateinit var ramDetail: TextView
    private lateinit var ramProgress: MemoryBreakdownView
    private lateinit var ramLegend: TextView
    private lateinit var cpuValue: TextView
    private lateinit var thermalValue: TextView
    private lateinit var batteryValue: TextView
    private lateinit var advice: TextView
    private lateinit var ramChart: HistoryChart
    private lateinit var cpuChart: HistoryChart
    private lateinit var gameSpinner: Spinner
    private lateinit var cleanRamButton: Button
    private lateinit var profileText: TextView
    private lateinit var memoryDetails: TextView
    private lateinit var sessionText: TextView
    private var sessionStartedAt = 0L
    private var sessionElapsedMs = 0L
    private var sessionActive = false
    private var peakBatteryTemp = -1
    private var peakThermalStatus = PowerManager.THERMAL_STATUS_NONE
    private var peakRamPercent = 0f
    private lateinit var sessionButton: Button
    private lateinit var games: List<GameEntry>
    private var previousCpu: CpuTicks? = null
    private var previousAppCpuMs: Long? = null
    private var previousWallMs: Long? = null
    private val ramHistory = ArrayList<Float>()
    private val cpuHistory = ArrayList<Float>()
    private var running = false
    private var lastMemory: MemoryBreakdown? = null
    private val perCorePrevious = HashMap<Int, Pair<Long, Long>>()
    private val perCoreHistory = HashMap<Int, MutableList<Float>>()
    private var cpuMonitorDialog: android.app.AlertDialog? = null

    data class GameEntry(val label: String, val packageName: String)
    data class CpuTicks(val total: Long, val idle: Long)
    data class MemoryBreakdown(val total: Long, val available: Long, val cache: Long, val used: Long, val active: Long, val inactive: Long, val buffers: Long, val shmem: Long, val sreclaimable: Long, val reservedNote: String)

    private val bg = 0xFF0A1018.toInt()
    private val surface = 0xFF151F2B.toInt()
    private val surface2 = 0xFF1B2937.toInt()
    private val textMain = 0xFFF0F5FA.toInt()
    private val textMuted = 0xFFA8B8C8.toInt()
    private val mint = 0xFF62D0AE.toInt()
    private val blue = 0xFF79AFFF.toInt()
    private val amber = 0xFFF2C16B.toInt()

    private val updater = object : Runnable {
        override fun run() {
            if (!running) return
            updateDashboard()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        sessionStartedAt = 0L
        buildDashboard()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2606)
        }
        discoverGames()
        updateDashboard()
    }

    override fun onResume() {
        super.onResume(); running = true
        handler.removeCallbacks(updater); handler.post(updater)
    }

    override fun onPause() {
        running = false; handler.removeCallbacks(updater); super.onPause()
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(48))
            setBackgroundColor(bg)
        }
        // Keep content clear of status/navigation bars on Android 15 edge-to-edge.
        window.decorView.setOnApplyWindowInsetsListener { _, insets ->
            val topInset: Int
            val bottomInset: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars())
                topInset = bars.top
                bottomInset = bars.bottom
            } else {
                @Suppress("DEPRECATION")
                topInset = insets.systemWindowInsetTop
                @Suppress("DEPRECATION")
                bottomInset = insets.systemWindowInsetBottom
            }
            root.setPadding(dp(18), dp(20) + topInset, dp(18), dp(34) + bottomInset + dp(12))
            insets
        }
        fun label(value: String, size: Float, color: Int = textMain, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
        fun section(value: String) {
            val t = label(value.uppercase(Locale.ROOT), 14f, textMuted, true)
            t.setPadding(0, dp(20), 0, dp(8)); root.addView(t)
        }
        fun card(view: View, padding: Int = 16) {
            view.background = rounded(surface, 18)
            view.setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
            root.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        fun button(title: String, color: Int, onClick: () -> Unit) = Button(this).apply {
            text = title; isAllCaps = false; textSize = 15f; setTextColor(textMain)
            background = rounded(color, 16); setPadding(dp(12), dp(7), dp(12), dp(7))
            setOnClickListener { onClick() }
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        header.addView(label("PIXEL RAM OPTIMIZER", 23f, textMain, true))
        header.addView(label("GAMING EDITION   •   VERSION 2.6   •   NO ROOT", 10f, mint, true))
        root.addView(header)

        section("Memory overview")
        val memCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(surface, 18); setPadding(dp(17), dp(16), dp(17), dp(16)) }
        ramValue = label("— GB / — GB", 30f, textMain, true)
        ramDetail = label("Reading memory information…", 13f, textMuted)
        ramProgress = MemoryBreakdownView(this)
        ramLegend = label("", 12f, textMuted)
        memCard.addView(ramValue); memCard.addView(ramDetail)
        memCard.addView(ramProgress, LinearLayout.LayoutParams(-1, dp(18)).apply { topMargin = dp(18); bottomMargin = dp(12) })
        memCard.addView(ramLegend)
        val detailsButton = Button(this).apply {
            text = "▾  ADVANCED MEMORY DETAILS"; isAllCaps = false; textSize = 11f
            setTextColor(mint); background = rounded(surface2, 12)
            setOnClickListener {
                memoryDetails.visibility = if (memoryDetails.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                text = if (memoryDetails.visibility == View.VISIBLE) "▴  HIDE MEMORY DETAILS" else "▾  ADVANCED MEMORY DETAILS"
            }
        }
        memCard.addView(detailsButton, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(10) })
        memoryDetails = label("Reading Linux memory counters…", 11f, textMuted)
        memoryDetails.visibility = View.GONE
        memoryDetails.setPadding(0, dp(10), 0, 0)
        memCard.addView(memoryDetails)
        val reserved = label("Hardware/kernel reserved memory is not exposed as a separate reliable value by standard Android APIs. It is not included in the RAM total reported by Android.", 11f, textMuted)
        reserved.setPadding(0, dp(10), 0, 0); memCard.addView(reserved)
        root.addView(memCard)

        cleanRamButton = button("✦   SMART CLEANUP", 0xFF176653.toInt()) { showRamCleanupDialog() }
        root.addView(cleanRamButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(3); bottomMargin = dp(7) })
        val cleanHint = label("Clears this app's disposable cache only. Android controls memory used by other apps.", 11f, textMuted)
        root.addView(cleanHint)
        ramChart = HistoryChart(this, "RAM pressure · used estimate", mint, "%")
        card(ramChart, 10)

        section("Monitoring session")
        sessionText = label("Gaming session: STOPPED\nDuration: 00:00:00\nPeak RAM pressure: —\nPeak battery temperature: —\nPeak thermal status: —", 14f, textMain)
        card(sessionText)
        sessionButton = button("▶   START GAMING SESSION", 0xFF176653.toInt()) { toggleGamingSession() }
        root.addView(sessionButton, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        root.addView(button("◷   SESSION HISTORY", surface2) { showSessionHistory() }, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(8) })
        root.addView(label("Background sampling runs in a foreground service while Gaming Session is active. A persistent notification is shown.", 10f, textMuted))

        section("Processor")
        root.addView(button("▥   OPEN PER-CORE CPU MONITOR", surface2) { showCpuMonitor() }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        root.addView(button("▤   SYSTEM INFORMATION", surface2) { showSystemInfo() }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        cpuValue = label("System CPU: sampling…\nApp CPU: sampling…", 17f, textMain)
        card(cpuValue)
        cpuChart = HistoryChart(this, "CPU · source selected automatically", blue, "%")
        card(cpuChart, 10)

        section("Thermal & battery")
        val thermalBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        thermalValue = label("Thermal status: —", 16f)
        batteryValue = label("Battery temperature: —", 16f)
        thermalBlock.addView(thermalValue); thermalBlock.addView(batteryValue)
        card(thermalBlock)

        section("Game profiles")
        gameSpinner = Spinner(this)
        card(gameSpinner, 7)
        profileText = label("Choose a game to see a suggested profile.", 13f, textMuted)
        card(profileText)
        root.addView(button("▶   START GAME", surface2) { launchSelectedGame() }, LinearLayout.LayoutParams(-1, dp(50)))
        root.addView(button("▦   BACKGROUND APP MANAGER", surface2) { showAppManagerDialog() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })

        section("Smart advisor")
        advice = label("Collecting system metrics…", 13f, textMuted)
        card(advice)
        root.addView(button("↻   REFRESH NOW", surface2) { updateDashboard() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        root.addView(button("APP SETTINGS", surface2) { openAppSettings() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })
        root.addView(label("Updates every 2 seconds while visible. Gaming Session records peaks only while active. Android controls other apps' processes; force-stopping apps repeatedly can increase reload time and battery use.", 10f, textMuted).apply { setPadding(2, dp(18), 2, 0) })

        scroll.addView(root); setContentView(scroll)
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun discoverGames() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = if (Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0)) else {
            @Suppress("DEPRECATION") packageManager.queryIntentActivities(intent, 0)
        }
        games = found.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName) return@mapNotNull null
            GameEntry(info.loadLabel(packageManager).toString(), pkg)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        val labels = listOf("Select an installed game") + games.map { it.label }
        gameSpinner.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
            private fun styled(value: String) = TextView(this@MainActivity).apply {
                text = value; textSize = 15f; setTextColor(textMain); setPadding(dp(12), dp(13), dp(12), dp(13)); setBackgroundColor(surface)
            }
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = styled(getItem(position) ?: "")
            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = styled(getItem(position) ?: "")
        }
        gameSpinner.setPopupBackgroundDrawable(android.graphics.drawable.ColorDrawable(surface))
        gameSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                profileText.text = if (position == 0) "Choose a game to see a suggested profile." else profileFor(games[position - 1])
            }
        }
    }

    private fun profileFor(game: GameEntry): String {
        val p = game.packageName.lowercase(Locale.ROOT)
        val demanding = listOf("wuthering", "zenless", "genshin", "hoyoverse", "pubg", "codm").any { p.contains(it) }
        return if (demanding) "Demanding-game profile: start with Balanced graphics, use a stable FPS cap, reduce shadows/effects first, and avoid charging during long sessions if heat rises. Settings are advisory; this app cannot alter another game's graphics settings."
        else "General profile: begin with default graphics and reduce shadows/post-processing if frame pacing or temperature becomes unstable."
    }

    private fun launchSelectedGame() {
        val index = gameSpinner.selectedItemPosition - 1
        if (index !in games.indices) { Toast.makeText(this, "Select a game first", Toast.LENGTH_SHORT).show(); return }
        val launch = packageManager.getLaunchIntentForPackage(games[index].packageName)
        if (launch == null) Toast.makeText(this, "No launch activity found", Toast.LENGTH_SHORT).show() else startActivity(launch)
    }

    private fun toggleGamingSession() {
        val prefs = getSharedPreferences("gaming_session", MODE_PRIVATE)
        val active = prefs.getBoolean("active", false)
        val intent = Intent(this, MonitoringService::class.java).apply {
            action = if (active) MonitoringService.ACTION_STOP else MonitoringService.ACTION_START
        }
        try {
            if (Build.VERSION.SDK_INT >= 26 && !active) startForegroundService(intent) else startService(intent)
            if (active) Toast.makeText(this, "Gaming session stopped", Toast.LENGTH_SHORT).show()
            else Toast.makeText(this, "Background monitoring started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start monitoring: ${e.message ?: "system restriction"}", Toast.LENGTH_LONG).show()
        }
        handler.postDelayed({ updateDashboard() }, 350)
    }


    private fun showSessionHistory() {
        val history = getSharedPreferences("gaming_session", MODE_PRIVATE).getString("history", "").orEmpty()
        showInfoDialog("GAMING SESSION HISTORY", if (history.isBlank()) "No completed sessions recorded yet. Start and stop a Gaming Session to create a record." else history)
    }

    private fun showSystemInfo() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val stat = android.os.StatFs(android.os.Environment.getDataDirectory().absolutePath)
        val totalStorage = stat.totalBytes; val freeStorage = stat.availableBytes
        @Suppress("DEPRECATION") val display = windowManager.defaultDisplay
        val refresh = try { display.mode.refreshRate } catch (_: Exception) { resources.displayMetrics.refreshRate }
        val resolution = "${resources.displayMetrics.widthPixels} × ${resources.displayMetrics.heightPixels} px"
        val cpuInfo = readCpuIdentity()
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val voltage = battery?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val health = battery?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val text = buildString {
            append("""DEVICE
Manufacturer: ${Build.MANUFACTURER}
Model: ${Build.MODEL}
Device: ${Build.DEVICE}
Board: ${Build.BOARD}

""")
            append("""ANDROID / KERNEL
Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})
Build ID: ${Build.DISPLAY}
Security patch: ${Build.VERSION.SECURITY_PATCH}
Kernel: ${System.getProperty("os.version") ?: "Unavailable"}

""")
            append("""DISPLAY
Resolution: $resolution
Refresh rate: ${String.format(Locale.US, "%.1f", refresh)} Hz

""")
            append("""MEMORY
Total: ${gb(mi.totalMem)} GB
Available: ${gb(mi.availMem)} GB
Used estimate: ${gb((mi.totalMem-mi.availMem).coerceAtLeast(0))} GB
RAM type/frequency: Not exposed to ordinary apps

""")
            append("""STORAGE
Data partition total: ${gb(totalStorage)} GB
Available: ${gb(freeStorage)} GB
Used: ${gb((totalStorage-freeStorage).coerceAtLeast(0))} GB
Filesystem: ${try { File(android.os.Environment.getDataDirectory().absolutePath).canonicalPath } catch (_: Exception) { "Unavailable" }}

""")
            append("""CPU / SOC
$cpuInfo
Logical processors: ${Runtime.getRuntime().availableProcessors()}
Architecture: ${System.getProperty("os.arch") ?: "Unavailable"}

""")
            append("""BATTERY
Temperature: ${if(temp>=0) String.format(Locale.US,"%.1f °C",temp/10f) else "Unavailable"}
Voltage: ${if(voltage>0) "$voltage mV" else "Unavailable"}
Health: ${batteryHealthName(health)}

""")
            append("""GPU / RADIO
GPU model, LPDDR frequency, storage technology, and detailed radio chipset are not reliably exposed by standard Android APIs without vendor access. Values are intentionally not guessed.""")
        }
        showInfoDialog("SYSTEM INFORMATION · PIXEL 8", text)
    }

    private fun batteryHealthName(value: Int): String = when(value) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"; BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"; BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"; BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unavailable"
    }

    private fun readCpuIdentity(): String {
        return try {
            val lines = File("/proc/cpuinfo").readLines()
            val model = lines.firstOrNull { it.startsWith("Hardware") || it.startsWith("Model name") }
                ?.substringAfter(':')?.trim()
            val implementer = lines.firstOrNull { it.trimStart().startsWith("CPU implementer") }?.substringAfter(':')?.trim()
            val part = lines.firstOrNull { it.trimStart().startsWith("CPU part") }?.substringAfter(':')?.trim()
            listOfNotNull(model, implementer?.let { "Implementer $it" }, part?.let { "Part $it" }).joinToString(" · ").ifBlank { "Tensor G3 (device identification)" }
        } catch (_: Exception) { "Tensor G3 · detailed /proc/cpuinfo fields restricted" }
    }

    private fun showInfoDialog(title: String, body: String) {
        val tv = TextView(this).apply { text = body; textSize = 13f; setTextColor(textMain); setPadding(dp(18), dp(14), dp(18), dp(14)) }
        val scroll = ScrollView(this).apply { addView(tv) }
        android.app.AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("CLOSE", null).show()
    }

    private fun showCpuMonitor() {
        val scroll = ScrollView(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)) }
        val summary = TextView(this).apply { textSize = 12f; setTextColor(textMuted); text = "Per-core load is calculated from /proc/stat deltas. Frequency may be unavailable on production builds." }
        column.addView(summary)
        val cards = Array(9) { i ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(surface, 14); setPadding(dp(12), dp(9), dp(12), dp(9)) }
            val title = TextView(this).apply { text = "CPU$i · reading…"; textSize = 14f; setTextColor(textMain); setTypeface(typeface, android.graphics.Typeface.BOLD) }
            val detail = TextView(this).apply { textSize = 11f; setTextColor(textMuted) }
            val chart = HistoryChart(this, "CORE $i LOAD", blue, "%")
            card.addView(title); card.addView(detail); card.addView(chart, LinearLayout.LayoutParams(-1, dp(86)))
            column.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            Triple(title, detail, chart)
        }
        scroll.addView(column)
        val dialog = android.app.AlertDialog.Builder(this).setTitle("CPU MONITOR · 9 CORES").setView(scroll).setPositiveButton("CLOSE", null).create()
        cpuMonitorDialog = dialog
        fun refresh() {
            val values = readPerCoreStats()
            for (i in 0..8) {
                val label = coreType(i)
                val freq = readCoreFrequency(i)
                val usage = values[i]
                cards[i].first.text = "CPU$i · $label"
                cards[i].second.text = "Load: ${usage?.let { String.format(Locale.US, "%.1f%%", it) } ?: "sampling / unavailable"}   •   Frequency: ${freq ?: "unavailable"}"
                if (usage != null) { val h = perCoreHistory.getOrPut(i) { ArrayList() }; h.add(usage); if(h.size>45) h.removeAt(0); cards[i].third.setValues(h) }
            }
        }
        dialog.setOnShowListener { refresh(); val tick = object: Runnable { override fun run() { if(dialog.isShowing) { refresh(); handler.postDelayed(this, 1200) } } }; handler.postDelayed(tick,1200) }
        dialog.show()
    }

    private fun coreType(index: Int): String {
        val part = try { File("/sys/devices/system/cpu/cpu$index/regs/identification/midr_el1").readText().trim().substringAfterLast('x').toLong(16).let { ((it shr 4) and 0xFFF).toInt() } } catch (_: Exception) { -1 }
        return when(part) { 0xD4E -> "Cortex-X3 · prime"; 0xD4D -> "Cortex-A715 · performance"; 0xD46 -> "Cortex-A510 · efficiency"; else -> "ARM core · type not exposed" }
    }

    private fun readCoreFrequency(index: Int): String? = try {
        val f = File("/sys/devices/system/cpu/cpu$index/cpufreq/scaling_cur_freq")
        if (!f.canRead()) null else "${f.readText().trim().toLong()/1000} MHz"
    } catch (_: Exception) { null }

    private fun readPerCoreStats(): Map<Int, Float?> {
        val result = HashMap<Int, Float?>()
        try {
            File("/proc/stat").forEachLine { line ->
                val m = Regex("^cpu(\\d+)\\s+(.+)$").find(line) ?: return@forEachLine
                val id = m.groupValues[1].toIntOrNull() ?: return@forEachLine
                if(id !in 0..8) return@forEachLine
                val v = m.groupValues[2].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
                if(v.size < 4) return@forEachLine
                val total = v.sum(); val idle = v[3] + (v.getOrNull(4) ?: 0L)
                val old = perCorePrevious[id]; perCorePrevious[id] = total to idle
                result[id] = if(old == null || total <= old.first) null else (((total-old.first)-(idle-old.second)).toFloat()/(total-old.first)*100f).coerceIn(0f,100f)
            }
        } catch (_: Exception) { for(i in 0..8) result[i] = null }
        return result
    }

    private fun showAppManagerDialog() {
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        list.addView(TextView(this).apply {
            text = "Installed launchable apps. Select APP INFO to open Android settings. If Android offers Force stop, you can confirm it there. On Android 14+, ordinary apps cannot directly terminate other apps."
            textSize = 13f
            setTextColor(textMuted)
            setPadding(0, 0, 0, dp(12))
        })
        games.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            val name = TextView(this).apply {
                text = "${app.label}\n${app.packageName}"
                textSize = 12f
                setTextColor(textMain)
                maxLines = 3
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val info = Button(this).apply {
                text = "APP INFO"
                isAllCaps = false
                textSize = 11f
                setTextColor(textMain)
                background = rounded(surface2, 10)
                setOnClickListener { openAppSettings(app.packageName) }
            }
            row.addView(name)
            row.addView(info, LinearLayout.LayoutParams(dp(92), dp(42)))
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0xFF2A3948.toInt()) },
                LinearLayout.LayoutParams(-1, dp(1)))
        }
        scroll.addView(list)
        android.app.AlertDialog.Builder(this)
            .setTitle("Background app manager")
            .setView(scroll)
            .setPositiveButton("CLOSE", null)
            .setNeutralButton("OPEN SYSTEM APP SETTINGS") { _, _ -> openAppSettings() }
            .show()
    }

    private fun showRamCleanupDialog() {
        val before = readMemoryBreakdown()
        android.app.AlertDialog.Builder(this)
            .setTitle("Smart RAM cleanup")
            .setMessage("Available now: ${gb(before.available)} GB\nReclaimable cache estimate: ${gb(before.cache)} GB\n\nThis action clears only Pixel RAM Optimizer's own disposable cache and makes a best-effort garbage-collection request for this process. Android does not grant ordinary apps permission to force-stop other apps or clear their caches.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("RUN SAFE CLEANUP") { _, _ -> performSafeCleanup() }
            .setNeutralButton("APP MANAGEMENT") { _, _ -> openAppSettings() }
            .show()
    }

    private fun performSafeCleanup() {
        cleanRamButton.isEnabled = false
        cleanRamButton.text = "CLEANING APP CACHE…"
        val before = readMemoryBreakdown()
        val deleted = clearDirectoryContents(cacheDir) + (externalCacheDir?.let { clearDirectoryContents(it) } ?: 0L)
        // Best-effort collection request for this process only; it does not kill other apps.
        try { Runtime.getRuntime().gc() } catch (_: Exception) { }
        handler.postDelayed({
            val after = readMemoryBreakdown()
            cleanRamButton.isEnabled = true
            cleanRamButton.text = "✦   SMART CLEANUP"
            updateDashboard()
            val delta = after.available - before.available
            val message = "Own-app cache removed: ${formatBytes(deleted)}\nAvailable RAM before: ${gb(before.available)} GB\nAvailable RAM after: ${gb(after.available)} GB\nChange: ${if (delta >= 0) "+" else ""}${gb(delta)} GB\n\nAndroid may reclaim cached memory automatically. A positive RAM change is not guaranteed; the main guaranteed action is removal of this app's disposable cache."
            android.app.AlertDialog.Builder(this).setTitle("Cleanup finished").setMessage(message).setPositiveButton("OK", null).show()
        }, 900L)
    }

    private fun clearDirectoryContents(dir: File): Long {
        var bytes = 0L
        val children = dir.listFiles() ?: return 0L
        for (file in children) {
            bytes += deleteRecursively(file)
        }
        return bytes
    }

    private fun deleteRecursively(file: File): Long {
        if (file.isDirectory) {
            var total = 0L
            file.listFiles()?.forEach { total += deleteRecursively(it) }
            if (file.delete()) return total
            return total
        }
        val length = file.length()
        return if (file.delete()) length else 0L
    }

    private fun openAppSettings(targetPackage: String = packageName) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$targetPackage")))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS))
        }
    }

    private fun readMemoryBreakdown(): MemoryBreakdown {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val total = mi.totalMem.coerceAtLeast(0L)
        val available = mi.availMem.coerceIn(0L, total)
        val mem = readProcMemInfo()
        // Linux meminfo counters overlap. This is an estimate for visualization, not an exact
        // sum of independently allocated memory. Cap it so Used + Cache + Available = Total.
        val rawCache = ((mem["Cached"] ?: 0L) + (mem["SReclaimable"] ?: 0L) + (mem["Buffers"] ?: 0L) - (mem["Shmem"] ?: 0L)).coerceAtLeast(0L)
        val cached = rawCache.coerceAtMost((total - available).coerceAtLeast(0L))
        val used = (total - available - cached).coerceAtLeast(0L)
        return MemoryBreakdown(
            total, available, cached, used,
            mem["Active"] ?: 0L, mem["Inactive"] ?: 0L,
            mem["Buffers"] ?: 0L, mem["Shmem"] ?: 0L,
            mem["SReclaimable"] ?: 0L, "Not separately exposed"
        )
    }

    private fun readProcMemInfo(): Map<String, Long> {
        return try {
            BufferedReader(FileReader("/proc/meminfo")).useLines { lines ->
                lines.mapNotNull { line ->
                    val parts = line.split(Regex("\\s+"))
                    if (parts.size >= 2) {
                        val value = parts[1].toLongOrNull() ?: return@mapNotNull null
                        val bytes = if (parts.getOrNull(2) == "kB") value * 1024L else value
                        parts[0].removeSuffix(":") to bytes
                    } else null
                }.toMap()
            }
        } catch (_: Exception) { emptyMap() }
    }

    private fun updateDashboard() {
        val mem = readMemoryBreakdown(); lastMemory = mem
        val usedPercent = if (mem.total > 0) (mem.used * 100f / mem.total) else 0f
        val inUsePercent = if (mem.total > 0) ((mem.total - mem.available) * 100f / mem.total) else 0f
        val cachePercent = if (mem.total > 0) (mem.cache * 100f / mem.total) else 0f
        val availPercent = if (mem.total > 0) (mem.available * 100f / mem.total) else 0f
        ramValue.text = "${gb(mem.total - mem.available)} GB / ${gb(mem.total)} GB"
        ramDetail.text = "In use incl. cache: ${inUsePercent.toInt()}%   •   Available: ${gb(mem.available)} GB"
        ramProgress.setSegments(mem.used.toFloat(), mem.cache.toFloat(), mem.available.toFloat(), mem.total.toFloat())
        ramLegend.text = "● Used ${gb(mem.used)} GB     ● Cache* ${gb(mem.cache)} GB     ● Available ${gb(mem.available)} GB"
        memoryDetails.text = "ACTIVE: ${gb(mem.active)} GB\nINACTIVE: ${gb(mem.inactive)} GB\nBUFFERS: ${gb(mem.buffers)} GB\nSHMEM: ${gb(mem.shmem)} GB\nSRECLAIMABLE: ${gb(mem.sreclaimable)} GB\n\n*Cache is an estimate derived from overlapping /proc/meminfo counters. It is not a separate physical partition and may be reclaimed by Android."
        ramHistory.add(inUsePercent)
        if (ramHistory.size > 60) ramHistory.removeAt(0)
        ramChart.setValues(ramHistory)

        val systemCpu = readSystemCpuLoad(); val appCpu = readAppCpuLoad()
        cpuValue.text = buildString {
            append("System CPU: "); append(if (systemCpu == null) "unavailable" else "${systemCpu.toInt()}%")
            append("\nApp CPU: "); append(if (appCpu == null) "sampling…" else "${appCpu.toInt()}% of total device capacity")
        }
        val chartCpu = systemCpu ?: appCpu
        cpuChart.setHeading(if (systemCpu != null) "System CPU load" else "App CPU load · process only")
        if (chartCpu != null) { cpuHistory.add(chartCpu); if (cpuHistory.size > 60) cpuHistory.removeAt(0) }
        cpuChart.setValues(cpuHistory)

        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) power.currentThermalStatus else -1
        thermalValue.text = "Thermal status: ${thermalName(thermal)}"
        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        batteryValue.text = if (temp >= 0) "Battery temperature: ${String.format(Locale.US, "%.1f", temp / 10f)} °C" else "Battery temperature: unavailable"
        val prefs = getSharedPreferences("gaming_session", MODE_PRIVATE)
        sessionActive = prefs.getBoolean("active", false)
        peakRamPercent = prefs.getFloat("peak_ram", 0f)
        peakBatteryTemp = prefs.getInt("peak_temp", -1)
        peakThermalStatus = prefs.getInt("peak_thermal", 0)
        val elapsedMs = if (sessionActive) (SystemClock.elapsedRealtime() - prefs.getLong("start_elapsed", SystemClock.elapsedRealtime())).coerceAtLeast(0L) else prefs.getLong("last_duration", 0L)
        val elapsed = elapsedMs / 1000L
        val hh = elapsed / 3600L; val mm = (elapsed % 3600L) / 60L; val ss = elapsed % 60L
        sessionButton.text = if(sessionActive) "■   STOP GAMING SESSION" else "▶   START GAMING SESSION"
        sessionButton.background = rounded(if(sessionActive) 0xFF7A3D43.toInt() else 0xFF176653.toInt(), 16)
        val peakTempText = if (peakBatteryTemp >= 0) String.format(Locale.US, "%.1f °C", peakBatteryTemp / 10f) else "—"
        val peakRamText = if (peakRamPercent > 0f) String.format(Locale.US, "%.0f%%", peakRamPercent) else "—"
        sessionText.text = String.format(Locale.US,
            "Gaming session: %s\nDuration: %02d:%02d:%02d\nPeak RAM pressure: %s\nPeak battery temperature: %s\nPeak thermal status: %s",
            if(sessionActive) "RUNNING · BACKGROUND SERVICE" else "STOPPED", hh, mm, ss, peakRamText, peakTempText,
            if (peakBatteryTemp >= 0 || peakRamPercent > 0f) thermalName(peakThermalStatus) else "—")
        advice.text = makeAdvice(inUsePercent, thermal, temp, systemCpu, mem.cache, mem.available)
    }

    private fun makeAdvice(ram: Float, thermal: Int, batteryTemp: Int, cpu: Float?, cache: Long, available: Long): String {
        val lines = mutableListOf<String>()
        if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) lines += "• Severe thermal state: pause gaming and let the phone cool."
        else if (thermal >= PowerManager.THERMAL_STATUS_MODERATE) lines += "• Thermal pressure elevated: lower graphics or FPS."
        else lines += "• Thermal status is not elevated according to Android's thermal API."
        if (batteryTemp >= 420) lines += "• Battery temperature is above 42 °C: reduce load and avoid charging during gaming."
        if (ram >= 90f || available < 700L * 1024L * 1024L) lines += "• Available memory is low. Android may reclaim cache automatically; close unused apps manually if needed."
        else lines += "• Memory headroom appears adequate. Cached memory is generally reclaimable and is not equivalent to unavailable RAM."
        if (cache > 0) lines += "• Reclaimable cache estimate: ${gb(cache)} GB. This is an estimate from /proc/meminfo fields."
        if (cpu != null && cpu >= 85f) lines += "• System CPU load is high at this sample."
        lines += "• Background App Manager opens Android App Info. On Android 14+, ordinary apps cannot directly kill other apps; use the system Force stop control when appropriate."
        return lines.joinToString("\n")
    }

    private fun readSystemCpuLoad(): Float? = try {
        BufferedReader(FileReader("/proc/stat")).use { reader ->
            val parts = reader.readLine().trim().split(Regex("\\s+"))
            if (parts.firstOrNull() != "cpu" || parts.size < 5) return null
            val values = parts.drop(1).take(8).map { it.toLong() }
            val idle = values[3] + (values.getOrNull(4) ?: 0L); val total = values.sum()
            val prev = previousCpu; previousCpu = CpuTicks(total, idle)
            if (prev == null) null else {
                val td = total - prev.total; val id = idle - prev.idle
                if (td <= 0) null else (((td - id).toFloat() / td) * 100f).coerceIn(0f, 100f)
            }
        }
    } catch (_: Exception) { null }

    private fun readAppCpuLoad(): Float? = try {
        val wall = SystemClock.elapsedRealtime(); val cpu = android.os.Process.getElapsedCpuTime()
        val ow = previousWallMs; val oc = previousAppCpuMs
        previousWallMs = wall; previousAppCpuMs = cpu
        if (ow == null || oc == null) null else {
            val wd = wall - ow; val cd = cpu - oc
            if (wd <= 0 || cd < 0) null else (cd.toFloat() / (wd.toFloat() * Runtime.getRuntime().availableProcessors().coerceAtLeast(1)) * 100f).coerceIn(0f, 100f)
        }
    } catch (_: Exception) { null }

    private fun thermalName(status: Int) = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "NORMAL"; PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
        PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"; PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
        PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"; PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"; else -> "NOT AVAILABLE"
    }

    private fun formatBytes(bytes: Long): String = if (bytes < 1024L * 1024L) "$bytes B" else "${String.format(Locale.US, "%.1f", bytes / 1048576.0)} MB"
    private fun gb(bytes: Long) = String.format(Locale.US, "%.2f", bytes / 1073741824.0)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class MemoryBreakdownView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var used = 0f; private var cache = 0f; private var available = 0f; private var total = 1f
        fun setSegments(u: Float, c: Float, a: Float, t: Float) { used = u; cache = c; available = a; total = t.coerceAtLeast(1f); invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val radius = height / 2f; val bounds = android.graphics.RectF(0f, 2f, width.toFloat(), height - 2f)
            paint.color = 0xFF263545.toInt(); canvas.drawRoundRect(bounds, radius, radius, paint)
            val usable = width.toFloat(); var x = 0f
            val parts = listOf(used to 0xFF79AFFF.toInt(), cache to 0xFFF2C16B.toInt(), available to 0xFF62D0AE.toInt())
            parts.forEach { (value, color) ->
                val w = usable * (value / total).coerceIn(0f, 1f)
                if (w > 0f) { paint.color = color; canvas.drawRect(x, 2f, (x + w).coerceAtMost(usable), height - 2f, paint); x += w }
            }
        }
    }

    private class HistoryChart(context: Context, private var heading: String, color: Int, private val suffix: String) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; strokeWidth = 4f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFF344553.toInt(); strokeWidth = 1f }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFFB8C6D2.toInt(); textSize = 30f }
        private var values: List<Float> = emptyList()
        fun setValues(newValues: List<Float>) { values = newValues.toList(); invalidate() }
        fun setHeading(value: String) { heading = value; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); val left = 18f; val right = width - 18f; val top = 52f; val bottom = height - 20f
            canvas.drawText(heading, left, 34f, label)
            for (i in 0..4) { val y = top + (bottom - top) * i / 4f; canvas.drawLine(left, y, right, y, grid) }
            if (values.size < 2) { canvas.drawText("Collecting samples…", left, (top + bottom) / 2f, label); return }
            val path = Path()
            values.forEachIndexed { i, v -> val x = left + (right - left) * i / max(1, values.size - 1); val y = bottom - (v.coerceIn(0f, 100f) / 100f) * (bottom - top); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
            canvas.drawPath(path, line); canvas.drawText("${values.last().toInt()}$suffix", right - 95f, top - 8f, label)
        }
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) { setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (150 * resources.displayMetrics.density).toInt()) }
    }
}
