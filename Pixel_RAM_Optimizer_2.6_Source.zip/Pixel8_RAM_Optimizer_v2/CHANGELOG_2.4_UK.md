# Pixel RAM Optimizer 2.4 — Gaming Edition

## Нове
- Додано розгортний Advanced Memory Details з Active, Inactive, Buffers, Shmem та SReclaimable з `/proc/meminfo`.
- RAM breakdown залишає Used, Cache estimate та Available окремими сегментами; у підписах пояснено, що кеш — оцінка з потенційно перекривних лічильників Linux.
- Додано Monitoring Session: тривалість роботи моніторингу, пікова температура батареї та найвищий зафіксований Thermal Status. Це не таймер ігрового процесу.
- CPU графік тепер змінює підпис залежно від джерела: System CPU або App CPU process-only.
- Оновлено adaptive launcher icon.
- Версія застосунку: 2.4, versionCode 6.

## Обмеження
- Hardware/kernel reserved RAM не показується окремим достовірним числом через відсутність універсального Android API для звичайних застосунків.
- App CPU — навантаження процесу Pixel RAM Optimizer, не всього пристрою.
- Smart Cleanup видаляє тільки disposable cache цього застосунку; сторонні процеси та кеші інших програм Android не дозволяє примусово очищати звичайному застосунку без системних прав.
- Cache estimate формується з `/proc/meminfo`; Linux memory counters можуть перекриватися і не є незалежними фізичними розділами RAM.
