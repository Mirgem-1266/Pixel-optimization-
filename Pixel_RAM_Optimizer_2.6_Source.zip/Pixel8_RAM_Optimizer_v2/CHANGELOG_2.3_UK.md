# Pixel RAM Optimizer 2.3 — Gaming Edition

## RAM dashboard
- Додано сегментовану смугу пам'яті: Used (пам'ять поза оціненим кешем), Cache (оцінка кешу, який потенційно може бути повернений системі), Available.
- Оцінка Cache формується з Cached + SReclaimable + Buffers − Shmem у `/proc/meminfo`, обмежується невикористаною частиною `MemTotal`.
- Окремо пояснено, що hardware/kernel reserved RAM не надається як надійна окрема величина стандартними API Android і не повинна вигадуватися.
- RAM-графік відображає зайняту пам'ять разом із кешем (MemTotal − MemAvailable).

## Smart Cleanup
- Додано підтверджувану безпечну дію очищення кешу самого Pixel RAM Optimizer (cacheDir та externalCacheDir).
- Показує обсяг видаленого кешу та доступну RAM до/після.
- Не завершує сторонні процеси, не очищує дані інших програм і не заявляє про гарантоване звільнення системної RAM.

## UI / branding
- Оновлено темний інтерфейс, картки, типографіку, кольорову сегментацію RAM та кнопки.
- Додано adaptive launcher icon у стилі RAM-чипа.
- Версія застосунку: 2.3 (versionCode 5).
