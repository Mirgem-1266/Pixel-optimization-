# Changelog 2.1

- CPU status now separates system-wide CPU load from app-process CPU usage.
- Added app-process CPU fallback for devices where `/proc/stat` is inaccessible.
- CPU graph clearly documents its source/fallback.
- Updated Android version metadata to 2.1 / versionCode 3.
- Retained no-root behavior and existing dashboard/game-profile functionality.
