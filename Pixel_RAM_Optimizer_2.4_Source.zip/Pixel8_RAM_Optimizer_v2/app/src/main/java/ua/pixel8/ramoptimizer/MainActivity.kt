package ua.pixel8.ramoptimizer

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.content.IntentFilter
import android.content.Context
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.BufferedReader
import java.io.FileReader
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var ramValue: TextView
    private lateinit var ramDetail: TextView
    private lateinit var ramProgress: MemoryBreakdownView
    private lateinit var ramLegend: TextView
    private lateinit var cpuValue: TextView
    private lateinit var thermalValue: TextView
    private lateinit var batteryValue: TextView
    private lateinit var advice: TextView
    private lateinit var ramChart: HistoryChart
    private lateinit var cpuChart: HistoryChart
    private lateinit var gameSpinner: Spinner
    private lateinit var cleanRamButton: Button
    private lateinit var profileText: TextView
    private lateinit var memoryDetails: TextView
    private lateinit var sessionText: TextView
    private var sessionStartedAt = 0L
    private var peakBatteryTemp = -1
    private var peakThermalStatus = PowerManager.THERMAL_STATUS_NONE
    private lateinit var games: List<GameEntry>
    private var previousCpu: CpuTicks? = null
    private var previousAppCpuMs: Long? = null
    private var previousWallMs: Long? = null
    private val ramHistory = ArrayList<Float>()
    private val cpuHistory = ArrayList<Float>()
    private var running = false
    private var lastMemory: MemoryBreakdown? = null

    data class GameEntry(val label: String, val packageName: String)
    data class CpuTicks(val total: Long, val idle: Long)
    data class MemoryBreakdown(val total: Long, val available: Long, val cache: Long, val used: Long, val active: Long, val inactive: Long, val buffers: Long, val shmem: Long, val sreclaimable: Long, val reservedNote: String)

    private val bg = 0xFF0A1018.toInt()
    private val surface = 0xFF151F2B.toInt()
    private val surface2 = 0xFF1B2937.toInt()
    private val textMain = 0xFFF0F5FA.toInt()
    private val textMuted = 0xFFA8B8C8.toInt()
    private val mint = 0xFF62D0AE.toInt()
    private val blue = 0xFF79AFFF.toInt()
    private val amber = 0xFFF2C16B.toInt()

    private val updater = object : Runnable {
        override fun run() {
            if (!running) return
            updateDashboard()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        sessionStartedAt = SystemClock.elapsedRealtime()
        buildDashboard()
        discoverGames()
        updateDashboard()
    }

    override fun onResume() {
        super.onResume(); running = true
        handler.removeCallbacks(updater); handler.post(updater)
    }

    override fun onPause() {
        running = false; handler.removeCallbacks(updater); super.onPause()
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(34))
            setBackgroundColor(bg)
        }
        fun label(value: String, size: Float, color: Int = textMain, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
        fun section(value: String) {
            val t = label(value.uppercase(Locale.ROOT), 14f, textMuted, true)
            t.setPadding(0, dp(20), 0, dp(8)); root.addView(t)
        }
        fun card(view: View, padding: Int = 16) {
            view.background = rounded(surface, 18)
            view.setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
            root.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        fun button(title: String, color: Int, onClick: () -> Unit) = Button(this).apply {
            text = title; isAllCaps = false; textSize = 15f; setTextColor(textMain)
            background = rounded(color, 16); setPadding(dp(12), dp(7), dp(12), dp(7))
            setOnClickListener { onClick() }
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        header.addView(label("PIXEL RAM OPTIMIZER", 23f, textMain, true))
        header.addView(label("GAMING EDITION   •   VERSION 2.4   •   NO ROOT", 10f, mint, true))
        root.addView(header)

        section("Memory overview")
        val memCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(surface, 18); setPadding(dp(17), dp(16), dp(17), dp(16)) }
        ramValue = label("— GB / — GB", 30f, textMain, true)
        ramDetail = label("Reading memory information…", 13f, textMuted)
        ramProgress = MemoryBreakdownView(this)
        ramLegend = label("", 12f, textMuted)
        memCard.addView(ramValue); memCard.addView(ramDetail)
        memCard.addView(ramProgress, LinearLayout.LayoutParams(-1, dp(18)).apply { topMargin = dp(18); bottomMargin = dp(12) })
        memCard.addView(ramLegend)
        val detailsButton = Button(this).apply {
            text = "▾  ADVANCED MEMORY DETAILS"; isAllCaps = false; textSize = 11f
            setTextColor(mint); background = rounded(surface2, 12)
            setOnClickListener {
                memoryDetails.visibility = if (memoryDetails.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                text = if (memoryDetails.visibility == View.VISIBLE) "▴  HIDE MEMORY DETAILS" else "▾  ADVANCED MEMORY DETAILS"
            }
        }
        memCard.addView(detailsButton, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(10) })
        memoryDetails = label("Reading Linux memory counters…", 11f, textMuted)
        memoryDetails.visibility = View.GONE
        memoryDetails.setPadding(0, dp(10), 0, 0)
        memCard.addView(memoryDetails)
        val reserved = label("Hardware/kernel reserved memory is not exposed as a separate reliable value by standard Android APIs. It is not included in the RAM total reported by Android.", 11f, textMuted)
        reserved.setPadding(0, dp(10), 0, 0); memCard.addView(reserved)
        root.addView(memCard)

        cleanRamButton = button("✦   SMART CLEANUP", 0xFF176653.toInt()) { showRamCleanupDialog() }
        root.addView(cleanRamButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(3); bottomMargin = dp(7) })
        val cleanHint = label("Clears this app's disposable cache only. Android controls memory used by other apps.", 11f, textMuted)
        root.addView(cleanHint)
        ramChart = HistoryChart(this, "RAM pressure · used estimate", mint, "%")
        card(ramChart, 10)

        section("Monitoring session")
        sessionText = label("Session: 00:00:00\nPeak battery temperature: —\nPeak thermal status: NORMAL", 14f, textMain)
        card(sessionText)

        section("Processor")
        cpuValue = label("System CPU: sampling…\nApp CPU: sampling…", 17f, textMain)
        card(cpuValue)
        cpuChart = HistoryChart(this, "CPU · source selected automatically", blue, "%")
        card(cpuChart, 10)

        section("Thermal & battery")
        val thermalBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        thermalValue = label("Thermal status: —", 16f)
        batteryValue = label("Battery temperature: —", 16f)
        thermalBlock.addView(thermalValue); thermalBlock.addView(batteryValue)
        card(thermalBlock)

        section("Game profiles")
        gameSpinner = Spinner(this)
        card(gameSpinner, 7)
        profileText = label("Choose a game to see a suggested profile.", 13f, textMuted)
        card(profileText)
        root.addView(button("▶   START GAME", surface2) { launchSelectedGame() }, LinearLayout.LayoutParams(-1, dp(50)))

        section("Smart advisor")
        advice = label("Collecting system metrics…", 13f, textMuted)
        card(advice)
        root.addView(button("↻   REFRESH NOW", surface2) { updateDashboard() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        root.addView(button("APP SETTINGS", surface2) { openAppSettings() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })
        root.addView(label("Updates every 2 seconds while visible. System CPU may be unavailable on some Android builds. Cache is reclaimable memory; repeatedly killing apps can increase reload time and battery use.", 10f, textMuted).apply { setPadding(2, dp(18), 2, 0) })

        scroll.addView(root); setContentView(scroll)
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun discoverGames() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = if (Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0)) else {
            @Suppress("DEPRECATION") packageManager.queryIntentActivities(intent, 0)
        }
        games = found.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName) return@mapNotNull null
            GameEntry(info.loadLabel(packageManager).toString(), pkg)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        val labels = listOf("Select an installed game") + games.map { it.label }
        gameSpinner.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
            private fun styled(value: String) = TextView(this@MainActivity).apply {
                text = value; textSize = 15f; setTextColor(textMain); setPadding(dp(12), dp(13), dp(12), dp(13)); setBackgroundColor(surface)
            }
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = styled(getItem(position) ?: "")
            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = styled(getItem(position) ?: "")
        }
        gameSpinner.setPopupBackgroundDrawable(android.graphics.drawable.ColorDrawable(surface))
        gameSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                profileText.text = if (position == 0) "Choose a game to see a suggested profile." else profileFor(games[position - 1])
            }
        }
    }

    private fun profileFor(game: GameEntry): String {
        val p = game.packageName.lowercase(Locale.ROOT)
        val demanding = listOf("wuthering", "zenless", "genshin", "hoyoverse", "pubg", "codm").any { p.contains(it) }
        return if (demanding) "Demanding-game profile: start with Balanced graphics, use a stable FPS cap, reduce shadows/effects first, and avoid charging during long sessions if heat rises. Settings are advisory; this app cannot alter another game's graphics settings."
        else "General profile: begin with default graphics and reduce shadows/post-processing if frame pacing or temperature becomes unstable."
    }

    private fun launchSelectedGame() {
        val index = gameSpinner.selectedItemPosition - 1
        if (index !in games.indices) { Toast.makeText(this, "Select a game first", Toast.LENGTH_SHORT).show(); return }
        val launch = packageManager.getLaunchIntentForPackage(games[index].packageName)
        if (launch == null) Toast.makeText(this, "No launch activity found", Toast.LENGTH_SHORT).show() else startActivity(launch)
    }

    private fun showRamCleanupDialog() {
        val before = readMemoryBreakdown()
        android.app.AlertDialog.Builder(this)
            .setTitle("Smart RAM cleanup")
            .setMessage("Available now: ${gb(before.available)} GB\nReclaimable cache estimate: ${gb(before.cache)} GB\n\nThis action clears only Pixel RAM Optimizer's own disposable cache and makes a best-effort garbage-collection request for this process. Android does not grant ordinary apps permission to force-stop other apps or clear their caches.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("RUN SAFE CLEANUP") { _, _ -> performSafeCleanup() }
            .setNeutralButton("APP MANAGEMENT") { _, _ -> openAppSettings() }
            .show()
    }

    private fun performSafeCleanup() {
        cleanRamButton.isEnabled = false
        cleanRamButton.text = "CLEANING APP CACHE…"
        val before = readMemoryBreakdown()
        val deleted = clearDirectoryContents(cacheDir) + (externalCacheDir?.let { clearDirectoryContents(it) } ?: 0L)
        // Best-effort collection request for this process only; it does not kill other apps.
        try { Runtime.getRuntime().gc() } catch (_: Exception) { }
        handler.postDelayed({
            val after = readMemoryBreakdown()
            cleanRamButton.isEnabled = true
            cleanRamButton.text = "✦   SMART CLEANUP"
            updateDashboard()
            val delta = after.available - before.available
            val message = "Own-app cache removed: ${formatBytes(deleted)}\nAvailable RAM before: ${gb(before.available)} GB\nAvailable RAM after: ${gb(after.available)} GB\nChange: ${if (delta >= 0) "+" else ""}${gb(delta)} GB\n\nAndroid may reclaim cached memory automatically. A positive RAM change is not guaranteed; the main guaranteed action is removal of this app's disposable cache."
            android.app.AlertDialog.Builder(this).setTitle("Cleanup finished").setMessage(message).setPositiveButton("OK", null).show()
        }, 900L)
    }

    private fun clearDirectoryContents(dir: File): Long {
        var bytes = 0L
        val children = dir.listFiles() ?: return 0L
        for (file in children) {
            bytes += deleteRecursively(file)
        }
        return bytes
    }

    private fun deleteRecursively(file: File): Long {
        if (file.isDirectory) {
            var total = 0L
            file.listFiles()?.forEach { total += deleteRecursively(it) }
            if (file.delete()) return total
            return total
        }
        val length = file.length()
        return if (file.delete()) length else 0L
    }

    private fun openAppSettings() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) }
    }

    private fun readMemoryBreakdown(): MemoryBreakdown {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val total = mi.totalMem.coerceAtLeast(0L)
        val available = mi.availMem.coerceIn(0L, total)
        val mem = readProcMemInfo()
        // Linux meminfo counters overlap. This is an estimate for visualization, not an exact
        // sum of independently allocated memory. Cap it so Used + Cache + Available = Total.
        val rawCache = ((mem["Cached"] ?: 0L) + (mem["SReclaimable"] ?: 0L) + (mem["Buffers"] ?: 0L) - (mem["Shmem"] ?: 0L)).coerceAtLeast(0L)
        val cached = rawCache.coerceAtMost((total - available).coerceAtLeast(0L))
        val used = (total - available - cached).coerceAtLeast(0L)
        return MemoryBreakdown(
            total, available, cached, used,
            mem["Active"] ?: 0L, mem["Inactive"] ?: 0L,
            mem["Buffers"] ?: 0L, mem["Shmem"] ?: 0L,
            mem["SReclaimable"] ?: 0L, "Not separately exposed"
        )
    }

    private fun readProcMemInfo(): Map<String, Long> {
        return try {
            BufferedReader(FileReader("/proc/meminfo")).useLines { lines ->
                lines.mapNotNull { line ->
                    val parts = line.split(Regex("\\s+"))
                    if (parts.size >= 2) {
                        val value = parts[1].toLongOrNull() ?: return@mapNotNull null
                        val bytes = if (parts.getOrNull(2) == "kB") value * 1024L else value
                        parts[0].removeSuffix(":") to bytes
                    } else null
                }.toMap()
            }
        } catch (_: Exception) { emptyMap() }
    }

    private fun updateDashboard() {
        val mem = readMemoryBreakdown(); lastMemory = mem
        val usedPercent = if (mem.total > 0) (mem.used * 100f / mem.total) else 0f
        val inUsePercent = if (mem.total > 0) ((mem.total - mem.available) * 100f / mem.total) else 0f
        val cachePercent = if (mem.total > 0) (mem.cache * 100f / mem.total) else 0f
        val availPercent = if (mem.total > 0) (mem.available * 100f / mem.total) else 0f
        ramValue.text = "${gb(mem.total - mem.available)} GB / ${gb(mem.total)} GB"
        ramDetail.text = "In use incl. cache: ${inUsePercent.toInt()}%   •   Available: ${gb(mem.available)} GB"
        ramProgress.setSegments(mem.used.toFloat(), mem.cache.toFloat(), mem.available.toFloat(), mem.total.toFloat())
        ramLegend.text = "● Used ${gb(mem.used)} GB     ● Cache* ${gb(mem.cache)} GB     ● Available ${gb(mem.available)} GB"
        memoryDetails.text = "ACTIVE: ${gb(mem.active)} GB\nINACTIVE: ${gb(mem.inactive)} GB\nBUFFERS: ${gb(mem.buffers)} GB\nSHMEM: ${gb(mem.shmem)} GB\nSRECLAIMABLE: ${gb(mem.sreclaimable)} GB\n\n*Cache is an estimate derived from overlapping /proc/meminfo counters. It is not a separate physical partition and may be reclaimed by Android."
        ramHistory.add(inUsePercent)
        if (ramHistory.size > 60) ramHistory.removeAt(0)
        ramChart.setValues(ramHistory)

        val systemCpu = readSystemCpuLoad(); val appCpu = readAppCpuLoad()
        cpuValue.text = buildString {
            append("System CPU: "); append(if (systemCpu == null) "unavailable" else "${systemCpu.toInt()}%")
            append("\nApp CPU: "); append(if (appCpu == null) "sampling…" else "${appCpu.toInt()}% of total device capacity")
        }
        val chartCpu = systemCpu ?: appCpu
        cpuChart.setHeading(if (systemCpu != null) "System CPU load" else "App CPU load · process only")
        if (chartCpu != null) { cpuHistory.add(chartCpu); if (cpuHistory.size > 60) cpuHistory.removeAt(0) }
        cpuChart.setValues(cpuHistory)

        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) power.currentThermalStatus else -1
        thermalValue.text = "Thermal status: ${thermalName(thermal)}"
        if (thermal >= 0) peakThermalStatus = max(peakThermalStatus, thermal)
        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        batteryValue.text = if (temp >= 0) "Battery temperature: ${String.format(Locale.US, "%.1f", temp / 10f)} °C" else "Battery temperature: unavailable"
        if (temp >= 0) peakBatteryTemp = max(peakBatteryTemp, temp)
        val elapsed = ((SystemClock.elapsedRealtime() - sessionStartedAt).coerceAtLeast(0L) / 1000L)
        val hh = elapsed / 3600L; val mm = (elapsed % 3600L) / 60L; val ss = elapsed % 60L
        val peakTempText = if (peakBatteryTemp >= 0) String.format(Locale.US, "%.1f °C", peakBatteryTemp / 10f) else "—"
        sessionText.text = String.format(Locale.US, "Session: %02d:%02d:%02d\nPeak battery temperature: %s\nPeak thermal status: %s", hh, mm, ss, peakTempText, thermalName(peakThermalStatus))
        advice.text = makeAdvice(inUsePercent, thermal, temp, systemCpu, mem.cache, mem.available)
    }

    private fun makeAdvice(ram: Float, thermal: Int, batteryTemp: Int, cpu: Float?, cache: Long, available: Long): String {
        val lines = mutableListOf<String>()
        if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) lines += "• Severe thermal state: pause gaming and let the phone cool."
        else if (thermal >= PowerManager.THERMAL_STATUS_MODERATE) lines += "• Thermal pressure elevated: lower graphics or FPS."
        else lines += "• Thermal status is not elevated according to Android's thermal API."
        if (batteryTemp >= 420) lines += "• Battery temperature is above 42 °C: reduce load and avoid charging during gaming."
        if (ram >= 90f || available < 700L * 1024L * 1024L) lines += "• Available memory is low. Android may reclaim cache automatically; close unused apps manually if needed."
        else lines += "• Memory headroom appears adequate. Cached memory is generally reclaimable and is not equivalent to unavailable RAM."
        if (cache > 0) lines += "• Reclaimable cache estimate: ${gb(cache)} GB. This is an estimate from /proc/meminfo fields."
        if (cpu != null && cpu >= 85f) lines += "• System CPU load is high at this sample."
        lines += "• Smart Cleanup affects this app only; Android prevents ordinary apps from force-stopping other apps."
        return lines.joinToString("\n")
    }

    private fun readSystemCpuLoad(): Float? = try {
        BufferedReader(FileReader("/proc/stat")).use { reader ->
            val parts = reader.readLine().trim().split(Regex("\\s+"))
            if (parts.firstOrNull() != "cpu" || parts.size < 5) return null
            val values = parts.drop(1).take(8).map { it.toLong() }
            val idle = values[3] + (values.getOrNull(4) ?: 0L); val total = values.sum()
            val prev = previousCpu; previousCpu = CpuTicks(total, idle)
            if (prev == null) null else {
                val td = total - prev.total; val id = idle - prev.idle
                if (td <= 0) null else (((td - id).toFloat() / td) * 100f).coerceIn(0f, 100f)
            }
        }
    } catch (_: Exception) { null }

    private fun readAppCpuLoad(): Float? = try {
        val wall = SystemClock.elapsedRealtime(); val cpu = android.os.Process.getElapsedCpuTime()
        val ow = previousWallMs; val oc = previousAppCpuMs
        previousWallMs = wall; previousAppCpuMs = cpu
        if (ow == null || oc == null) null else {
            val wd = wall - ow; val cd = cpu - oc
            if (wd <= 0 || cd < 0) null else (cd.toFloat() / (wd.toFloat() * Runtime.getRuntime().availableProcessors().coerceAtLeast(1)) * 100f).coerceIn(0f, 100f)
        }
    } catch (_: Exception) { null }

    private fun thermalName(status: Int) = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "NORMAL"; PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
        PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"; PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
        PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"; PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"; else -> "NOT AVAILABLE"
    }

    private fun formatBytes(bytes: Long): String = if (bytes < 1024L * 1024L) "$bytes B" else "${String.format(Locale.US, "%.1f", bytes / 1048576.0)} MB"
    private fun gb(bytes: Long) = String.format(Locale.US, "%.2f", bytes / 1073741824.0)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class MemoryBreakdownView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var used = 0f; private var cache = 0f; private var available = 0f; private var total = 1f
        fun setSegments(u: Float, c: Float, a: Float, t: Float) { used = u; cache = c; available = a; total = t.coerceAtLeast(1f); invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val radius = height / 2f; val bounds = android.graphics.RectF(0f, 2f, width.toFloat(), height - 2f)
            paint.color = 0xFF263545.toInt(); canvas.drawRoundRect(bounds, radius, radius, paint)
            val usable = width.toFloat(); var x = 0f
            val parts = listOf(used to 0xFF79AFFF.toInt(), cache to 0xFFF2C16B.toInt(), available to 0xFF62D0AE.toInt())
            parts.forEach { (value, color) ->
                val w = usable * (value / total).coerceIn(0f, 1f)
                if (w > 0f) { paint.color = color; canvas.drawRect(x, 2f, (x + w).coerceAtMost(usable), height - 2f, paint); x += w }
            }
        }
    }

    private class HistoryChart(context: Context, private var heading: String, color: Int, private val suffix: String) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; strokeWidth = 4f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFF344553.toInt(); strokeWidth = 1f }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFFB8C6D2.toInt(); textSize = 30f }
        private var values: List<Float> = emptyList()
        fun setValues(newValues: List<Float>) { values = newValues.toList(); invalidate() }
        fun setHeading(value: String) { heading = value; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); val left = 18f; val right = width - 18f; val top = 52f; val bottom = height - 20f
            canvas.drawText(heading, left, 34f, label)
            for (i in 0..4) { val y = top + (bottom - top) * i / 4f; canvas.drawLine(left, y, right, y, grid) }
            if (values.size < 2) { canvas.drawText("Collecting samples…", left, (top + bottom) / 2f, label); return }
            val path = Path()
            values.forEachIndexed { i, v -> val x = left + (right - left) * i / max(1, values.size - 1); val y = bottom - (v.coerceIn(0f, 100f) / 100f) * (bottom - top); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
            canvas.drawPath(path, line); canvas.drawText("${values.last().toInt()}$suffix", right - 95f, top - 8f, label)
        }
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) { setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (150 * resources.displayMetrics.density).toInt()) }
    }
}
