package ua.pixel8.ramoptimizer

import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.provider.Settings
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.BufferedReader
import java.io.FileReader
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var ramValue: TextView
    private lateinit var ramDetail: TextView
    private lateinit var cpuValue: TextView
    private lateinit var thermalValue: TextView
    private lateinit var batteryValue: TextView
    private lateinit var advice: TextView
    private lateinit var ramChart: HistoryChart
    private lateinit var cpuChart: HistoryChart
    private lateinit var gameSpinner: Spinner
    private lateinit var profileText: TextView
    private lateinit var games: List<GameEntry>
    private var previousCpu: CpuTicks? = null
    private val ramHistory = ArrayList<Float>()
    private val cpuHistory = ArrayList<Float>()
    private var running = false

    data class GameEntry(val label: String, val packageName: String)
    data class CpuTicks(val total: Long, val idle: Long)

    private val updater = object : Runnable {
        override fun run() {
            if (!running) return
            updateDashboard()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildDashboard()
        discoverGames()
        updateDashboard()
    }

    override fun onResume() {
        super.onResume()
        running = true
        handler.removeCallbacks(updater)
        handler.post(updater)
    }

    override fun onPause() {
        running = false
        handler.removeCallbacks(updater)
        super.onPause()
    }

    private fun buildDashboard() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
            setBackgroundColor(0xFF0B1118.toInt())
        }

        fun text(value: String, size: Float, color: Int = 0xFFF2F5F8.toInt()) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, dp(5), 0, dp(5))
            }

        fun section(title: String) {
            val t = text(title, 17f)
            t.setPadding(0, dp(16), 0, dp(7))
            root.addView(t)
        }

        fun card(view: View) {
            view.setBackgroundColor(0xFF18232E.toInt())
            view.setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, dp(5), 0, dp(5))
            root.addView(view, lp)
        }

        root.addView(text("PIXEL RAM OPTIMIZER", 23f))
        root.addView(text("GAMING EDITION  •  VERSION 2.0  •  NO ROOT", 11f, 0xFF91A7B9.toInt()))

        section("MEMORY DASHBOARD")
        ramValue = text("— GB", 27f)
        ramDetail = text("Reading memory information…", 13f, 0xFFB8C6D2.toInt())
        val ramBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(ramValue); addView(ramDetail)
        }
        card(ramBlock)
        ramChart = HistoryChart(this, "RAM usage", 0xFF65C8A5.toInt(), "%")
        card(ramChart)

        section("PROCESSOR")
        cpuValue = text("CPU load: —", 22f)
        card(cpuValue)
        cpuChart = HistoryChart(this, "System CPU load", 0xFF77A9F7.toInt(), "%")
        card(cpuChart)

        section("THERMAL & BATTERY")
        thermalValue = text("Thermal status: —", 16f)
        batteryValue = text("Battery temperature: —", 16f)
        val thermalBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(thermalValue); addView(batteryValue)
        }
        card(thermalBlock)

        section("GAME PROFILES")
        gameSpinner = Spinner(this)
        card(gameSpinner)
        profileText = text("Choose a game to see a suggested profile.", 13f, 0xFFB8C6D2.toInt())
        card(profileText)
        val launch = Button(this).apply {
            text = "START GAME"
            setOnClickListener { launchSelectedGame() }
        }
        root.addView(launch)

        section("SMART OPTIMIZATION ADVISOR")
        advice = text("Collecting system metrics…", 14f)
        card(advice)

        val refresh = Button(this).apply {
            text = "REFRESH NOW"
            setOnClickListener { updateDashboard() }
        }
        root.addView(refresh)

        val settings = Button(this).apply {
            text = "ANDROID APP SETTINGS"
            setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) }
        }
        root.addView(settings)

        root.addView(text(
            "Metrics refresh every 2 seconds while this screen is visible. CPU load is estimated from /proc/stat when readable. Android does not expose a universal third-party FPS API. This app does not kill background apps or alter system scheduling.",
            11f, 0xFF8193A2.toInt()
        ))
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun discoverGames() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = if (Build.VERSION.SDK_INT >= 33) {
            packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(intent, 0)
        }
        games = found.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName) return@mapNotNull null
            GameEntry(info.loadLabel(packageManager).toString(), pkg)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }

        val labels = listOf("Select an installed game") + games.map { it.label }
        gameSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        gameSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                profileText.text = if (position == 0) "Choose a game to see a suggested profile."
                else profileFor(games[position - 1])
            }
        }
    }

    private fun profileFor(game: GameEntry): String {
        val p = game.packageName.lowercase(Locale.ROOT)
        val highLoad = listOf("wuthering", "zenless", "genshin", "hoyoverse", "pubg", "codm")
            .any { p.contains(it) }
        return if (highLoad) {
            "Detected demanding-game profile. Suggested starting point: use the game's Balanced preset, cap FPS to a stable value, reduce shadows/effects first, disable high-resolution extras if heat rises, and avoid gaming while charging when possible. This app cannot apply these settings automatically."
        } else {
            "General game profile. Start with the game's default graphics preset, then lower shadows and post-processing if frame pacing or temperature becomes unstable. This app does not change the game's settings."
        }
    }

    private fun launchSelectedGame() {
        val index = gameSpinner.selectedItemPosition - 1
        if (index !in games.indices) {
            Toast.makeText(this, "Select a game first", Toast.LENGTH_SHORT).show()
            return
        }
        val entry = games[index]
        val launchIntent = packageManager.getLaunchIntentForPackage(entry.packageName)
        if (launchIntent == null) {
            Toast.makeText(this, "No launch activity found", Toast.LENGTH_SHORT).show()
        } else {
            startActivity(launchIntent)
        }
    }

    private fun updateDashboard() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val used = (mi.totalMem - mi.availMem).coerceAtLeast(0L)
        val usedPercent = if (mi.totalMem > 0) used * 100f / mi.totalMem else 0f
        ramValue.text = "${gb(used)} GB / ${gb(mi.totalMem)} GB"
        ramDetail.text = "Estimated in use: ${usedPercent.toInt()}%    Available: ${gb(mi.availMem)} GB"
        ramHistory.add(usedPercent)
        if (ramHistory.size > 60) ramHistory.removeAt(0)
        ramChart.setValues(ramHistory)

        val cpu = readCpuLoad()
        cpuValue.text = if (cpu == null) "CPU load: unavailable" else "CPU load: ${cpu.toInt()}%"
        if (cpu != null) {
            cpuHistory.add(cpu)
            if (cpuHistory.size > 60) cpuHistory.removeAt(0)
        }
        cpuChart.setValues(cpuHistory)

        val power = getSystemService(POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) power.currentThermalStatus else -1
        thermalValue.text = "Thermal status: ${thermalName(thermal)}"
        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        batteryValue.text = if (tempTenths >= 0)
            "Battery sensor: ${String.format(Locale.US, "%.1f", tempTenths / 10f)} °C"
        else "Battery sensor: unavailable"

        advice.text = makeAdvice(usedPercent, thermal, tempTenths, cpu)
    }

    private fun makeAdvice(ram: Float, thermal: Int, batteryTemp: Int, cpu: Float?): String {
        val lines = mutableListOf<String>()
        if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) {
            lines += "• Severe thermal state: pause gaming and allow the phone to cool."
        } else if (thermal >= PowerManager.THERMAL_STATUS_MODERATE) {
            lines += "• Thermal pressure is elevated: lower graphics or FPS to reduce sustained heat."
        } else {
            lines += "• Thermal status is not elevated according to Android's thermal API."
        }
        if (batteryTemp >= 420) lines += "• Battery temperature is above 42 °C: reduce load and avoid charging during gaming."
        if (ram >= 90f) lines += "• Memory use is high: close apps manually from Recents if they are not needed."
        else if (ram >= 80f) lines += "• Memory use is elevated; check whether a specific app is behaving unusually."
        else lines += "• Memory pressure appears manageable. Cached RAM is normally reusable by Android."
        if (cpu != null && cpu >= 85f) lines += "• CPU load is high at this sample; check whether the game is still loading or background work is active."
        lines += "• Avoid RAM-cleaner apps: repeatedly killing cached apps can increase reloads and battery use."
        return lines.joinToString("\n")
    }

    private fun readCpuLoad(): Float? {
        return try {
            BufferedReader(FileReader("/proc/stat")).use { reader ->
                val parts = reader.readLine().trim().split(Regex("\\s+"))
                if (parts.firstOrNull() != "cpu" || parts.size < 5) return null
                val values = parts.drop(1).take(8).map { it.toLong() }
                val idle = values[3] + (values.getOrNull(4) ?: 0L)
                val total = values.sum()
                val prev = previousCpu
                previousCpu = CpuTicks(total, idle)
                if (prev == null) null else {
                    val totalDelta = total - prev.total
                    val idleDelta = idle - prev.idle
                    if (totalDelta <= 0) null
                    else (((totalDelta - idleDelta).toFloat() / totalDelta) * 100f).coerceIn(0f, 100f)
                }
            }
        } catch (_: Exception) { null }
    }

    private fun thermalName(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "NORMAL"
        PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
        PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
        PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
        PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
        else -> "NOT AVAILABLE"
    }

    private fun gb(bytes: Long) = String.format(Locale.US, "%.2f", bytes / 1073741824.0)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class HistoryChart(
        context: Context,
        private val heading: String,
        color: Int,
        private val suffix: String
    ) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; strokeWidth = 4f; style = Paint.Style.STROKE
        }
        private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = 0xFF344553.toInt(); strokeWidth = 1f
        }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = 0xFFB8C6D2.toInt(); textSize = 30f
        }
        private var values: List<Float> = emptyList()

        fun setValues(newValues: List<Float>) {
            values = newValues.toList()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val left = 18f
            val right = width - 18f
            val top = 52f
            val bottom = height - 20f
            canvas.drawText(heading, left, 34f, label)
            for (i in 0..4) {
                val y = top + (bottom - top) * i / 4f
                canvas.drawLine(left, y, right, y, grid)
            }
            if (values.size < 2) {
                canvas.drawText("Collecting samples…", left, (top + bottom) / 2f, label)
                return
            }
            val path = Path()
            values.forEachIndexed { i, v ->
                val x = left + (right - left) * i / max(1, values.size - 1)
                val y = bottom - (v.coerceIn(0f, 100f) / 100f) * (bottom - top)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, line)
            canvas.drawText("${values.last().toInt()}$suffix", right - 95f, top - 8f, label)
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = MeasureSpec.getSize(widthMeasureSpec)
            setMeasuredDimension(w, dp(150))
        }

        private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    }
}
